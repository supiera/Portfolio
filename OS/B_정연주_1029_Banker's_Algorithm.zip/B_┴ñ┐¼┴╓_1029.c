#include <stdio.h>
#include <Windows.h>
#define MAX 3

typedef struct Processor{
	int processorNum;
	int allocation;
	int max;
	int need;
}PCR;

void output_data(PCR ps[], int avail){
	int i;
	printf("     Processor   Allocation     Max     Need\n");
	for (i = 0; i < MAX; i++)
		printf("        [P%d]        %2d          %2d       %2d\n", i, ps[i].allocation , ps[i].max , ps[i].need);
	printf("                [Available : %d]\n\n", avail);
}

int main(){
	PCR ps[MAX];
	int i, j, resource;
	int avail = 0, request = 0;

	printf("Enter the Number Of Resource : ");
	scanf("%d", &resource);

	fflush(stdin);
	for (i = 0; i < MAX; i++){
		printf("Enter the [P%d] Allocation, Max : ", i);
		scanf("%d%d", &ps[i].allocation, &ps[i].max);
		ps[i].processorNum = i;
		ps[i].need = ps[i].max - ps[i].allocation;
		avail += ps[i].allocation;
	}
	avail = resource - avail;		// 1��° available
	printf("\n");
	while (1){
		if (avail < 0 || avail < request){
			printf("\t<< The system is in an unsafe state >>\n\n");//�Ҿ���
			break;
		}
		output_data(ps, avail);

		if (avail == resource){		//������� ��
			printf("\t<< The system is in a safe state >>\n\n");		//����
			break;
		}
	
		for (i = 0; i < MAX; i++){
			request = ps[i].need;
			if (request != 0)
				if (request <= ps[i].need){
					if (avail >= request){
						avail = avail - request;
						ps[i].allocation = ps[i].allocation + request;
						ps[i].need = ps[i].need - request;
						ps[i].max = 0;

						output_data(ps, avail);
						if (ps[i].need == 0) {
							avail += ps[i].allocation;
							ps[i].allocation = 0;		//�ݳ�
							printf(" -- Process %d runs to completion --\n\n", ps[i].processorNum);
							break;
						}
					}
				}
		}
	} 
	system("PAUSE");
	return 0;
}
package com.example.dm.teamintroduction;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;


public class MainActivity extends Activity {

    private EditText loginAccountText;
    private EditText loginPasswordText;
    private EditText signupAccountText;
    private EditText signupPasswordText;
    private EditText signupNicknameText;
    private Button loginButton;
    private Button signupButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.loginAccountText = (EditText) findViewById(R.id.accountText);
        this.loginPasswordText = (EditText) findViewById(R.id.passwordText);
        this.signupAccountText = (EditText) findViewById(R.id.signUpAccountText);
        this.signupPasswordText = (EditText) findViewById(R.id.signUpPasswordText);
        this.signupNicknameText = (EditText) findViewById(R.id.signUpNameText);
        this.loginButton = (Button) findViewById(R.id.loginButton);
        this.signupButton = (Button) findViewById(R.id.signUpButton);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // signUp();
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // login();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void signUp()
    {
        String account = this.signupAccountText.getText().toString();
        String nickName = this.signupNicknameText.getText().toString();
        String password = this.signupPasswordText.getText().toString();

        UserAccount ua = new UserAccount(account,nickName,password);
        String uaJson = new Gson().toJson(ua);

        AsyncTask<String, Void, String> client = new MyRestClient();
        client.execute("POST", "http://shcspkdy.appspot.com/service/UserAccount",uaJson);

        String resultString = client.get();
    }

    public void login()
    {

    }
}

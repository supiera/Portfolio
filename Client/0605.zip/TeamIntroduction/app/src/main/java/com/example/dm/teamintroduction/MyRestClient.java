package com.example.dm.teamintroduction;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by 04MB01 on 2015-06-05.
 */
public class MyRestClient extends AsyncTask<String, Void, String> {
    @Override
    protected String doInBackground(String... params) {
        String resultJson = "";
        String method = params[0];
        String url = params[1];
        String json = params[2];
        try {
            URL serviceURL = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) serviceURL.openConnection();
            conn.setRequestProperty("Content Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestMethod(method);
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes());
            os.flush();

            String s;
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((s = br.readLine()) != null) {
                resultJson = resultJson + s;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultJson;
    }
}
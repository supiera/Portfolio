package kr.ac.shinhan.csp;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("/UserAccount")		//url ��� 
public class UserAccountService {
	private static PersistenceManagerFactory PMF;
	
	public UserAccountService(){
		PMF = JDOHelper.getPersistenceManagerFactory("transactions-optional");
	}
	
	//������ post�� ȣ���Ѵ�
	@POST
	@Consumes(MediaType.APPLICATION_JSON)		//Ŭ�� json���� ���� �ִ°�
	@Produces(MediaType.APPLICATION_JSON)		//
	public Response createUserAccount(UserAccount account){		//result ��� ��ü�� �����ؼ� isSuccess�� �ϰ� message

		// DB�� ����
		PersistenceManager pm = PMF.getPersistenceManager();
		pm.makePersistent(account);
		
		Result result = new Result(true, "Success");
		Response response = Response.ok().entity(result).build();
		return response;
	}
	
	@GET
	@Path("/GetUserAccount/{accountKey}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUser(@PathParam("accountKey") String accountKey){ //url���� �Ķ���͸� �޼ҵ��Ķ���ͷ�
		PersistenceManager pm = PMF.getPersistenceManager();
		long longKey = Long.parseLong(accountKey);
		UserAccount userAccount = pm.getObjectById(UserAccount.class, longKey);
		Response response = Response.ok().entity(userAccount).build();
		return response;
	}

	@DELETE
	@Path("/{accountKey}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteUserAccount(@PathParam("accountKey") String accountKey){
		PersistenceManager pm = PMF.getPersistenceManager();
		long longKey = Long.parseLong(accountKey);
		UserAccount userAccount = pm.getObjectById(UserAccount.class, longKey);
		pm.deletePersistent(userAccount);
		
		Result result = new Result(true, "Success");
		Response response = Response.ok().entity(result).build();
		return response;
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateUserAccount(UserAccount account){
		PersistenceManager pm = PMF.getPersistenceManager();
		UserAccount ua = pm.getObjectById(UserAccount.class, account.getKey());
		
		//�ϳ��ϳ� �� �Ȱ����͵� �ǰ�  ������ �����Ʈ�� ������ Ű��
		account.setKey(ua.getKey()); 
		pm.makePersistent(account);
		
		Result result = new Result(true, "Success");
		Response response = Response.ok().entity(result).build();
		return response;
	}

}

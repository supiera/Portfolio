package kr.ac.shinhanyj;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class IdealProject  extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		resp.setContentType("text/plain");
		resp.setCharacterEncoding("UTF-8");
		resp.getWriter().println("Ideal Team Project ");
		resp.getWriter().println(" <html> " +
		"<body>" + "<h1>������Ʈ �̸� : RIA(Run into Action)</h1>");
		resp.getWriter().println(" ���� : �ڴ��, ���Ͻ�, �迹��, ������");
		resp.getWriter().println(" ");
	}
}
package kr.ac.shinhan.csp;

public class RegistMember {

}

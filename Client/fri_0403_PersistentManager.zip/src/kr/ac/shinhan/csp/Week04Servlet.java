package kr.ac.shinhan.csp;
import java.io.IOException;

import javax.jdo.PersistenceManager;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class Week04Servlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {

		String name = req.getParameter("name");
		String socialNum = req.getParameter("socialNum");
		TeamMember tm = new TeamMember(name, socialNum);
		
		PersistenceManager pm = MyPersistentManager.getManager();
		pm.makePersistent(tm);
		
		resp.setCharacterEncoding("UTF-8"); 
		resp.setContentType("text/plain"); 
		
		resp.getWriter().println("<html>"); 
 		resp.getWriter().println("<body>"); 
 		resp.getWriter().println("name : "+tm.getName() +"<br>"); 
 		resp.getWriter().println("socialNumber : "+tm.getSocialNum() +"<br>"); 
 		 
 		resp.getWriter().println("</body>"); 
 		resp.getWriter().println("</html>"); 

	}
}
